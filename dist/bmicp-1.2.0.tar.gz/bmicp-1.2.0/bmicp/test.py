import bm_icp

bm_icp.bmicp("/Users/todayousuke/Desktop/objectdetection/bm_icp_v2/bm_icp/config.ini", "/Users/todayousuke/Desktop/objectdetection/bm_IcP/sample/20160524_ITbM-DMSO_3rd_03.jpg")